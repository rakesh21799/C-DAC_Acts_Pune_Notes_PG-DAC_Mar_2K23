
public class TestGrowableArray {
	
	public static void main(String[] args) {
		GrowableArray gArray = new GrowableArray(2);
		gArray.insert(1);
		gArray.insert(2);
		gArray.insert(3);
		System.out.println(gArray);
	}
	
	

}
