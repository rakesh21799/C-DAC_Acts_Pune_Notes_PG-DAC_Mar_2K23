public class PrintPrime {
	public static boolean IsPrime(int no) {
		int i = 2;

		while (i <= (no - 1)) {
			if ((no % i) == 0)
				return false;
			i = i + 1;
		}

		return true;
	}

	public static void PrintPrimeBetween2and100() {
		int no = 2;

		while (no <= 100) {
			boolean isPrime = IsPrime(no);

			if (isPrime == true) {
				System.out.println(no);
			}

			no = no + 1;
		}
	}

	public static void PrintPrimeBetween2and100UsingFor() {
		for (int no = 2; no <= 100; ++no) {
			if (IsPrime(no)) {
				System.out.println(no);
			}
		}
	}

	public static void PrintNonPrimeBetween2and100UsingFor() {
		for (int no = 2; no <= 100; ++no) {
/*			
			if (IsPrime(no)) {
			} else {
				System.out.println(no);
			}
*/
/*
			if (IsPrime(no) == false) {
				System.out.println(no);
			}
*/
			if (!IsPrime(no)) {
				System.out.println(no);
			}
		}
	}

	public static void main(String[] args) {
		//PrintPrimeBetween2and100();
		//PrintPrimeBetween2and100UsingFor();
		PrintNonPrimeBetween2and100UsingFor();
	}
}
