package com.dac.java.app;

import java.lang.Math;

import com.dac.java.shape.Point;

// Uncomment following when using useShapeInheritance() and comment them when using useLineAndRectangle() 
//import com.dac.java.shapeinheritance.Line;
//import com.dac.java.shapeinheritance.Rectangle;
//import com.dac.java.shapeinheritance.Shape;

// Uncomment following when using useLineAndRectangle() and comment them when using useShapeInheritance()
import com.dac.java.shape.Line;
import com.dac.java.shape.Rectangle;

import com.dac.java.student.StudentInfo;

// Static import of Math.max => allow us to directly access static method
// max() without having to write Math.max()
import static java.lang.Math.max;

public class MainApp {
	static {
		System.out.println("Static block of MainApp");
	}

	public static int Abs(int no) {
		/*
		if (no < 0) {
			no *= -1;
		}
		return no;
		*/
		return (no < 0)?(-1 * no):no;
	}

	public static void useStudentInfoClass() {
		StudentInfo s1 = new StudentInfo();
		StudentInfo s2 = new StudentInfo("name 2");

		System.out.println("Roll No = " + s1.getRollNo() + ", Name = " + s1.getName());
		System.out.println("Roll No = " + s2.getRollNo() + ", Name = " + s2.getName());

		System.out.println("Abs of -5 = " + Abs(-5));
		System.out.println("Abs of 5 = " + Abs(5));

		System.out.println("Abs of -5 = " + Math.abs(-5));
		System.out.println("Abs of 5 = " + Math.abs(5));

		System.out.println("Max of 10 and 5 = " + max(10, 5));
	}

	public static void useLineAndRectangle() {
		// Comment/Uncomment appropriate import statements at top of this source file.
		Line[] lines = new Line[10];
		int lineCount = 0;
		Rectangle[] rects = new Rectangle[10];
		int rectCount = 0;
		char[] shapesDrawn = new char[20];
		int shapesCount = 0;

		// Draw a Line
		lines[lineCount] = new Line(new Point(1, 1), new Point(10, 10));
		lines[lineCount].Draw();
		++lineCount;
		shapesDrawn[shapesCount] = 'L';
		++shapesCount;

		// Draw a rectangle 
		rects[rectCount] = new Rectangle(new Point(-10, -10), new Point(100, 100));
		rects[rectCount].Draw();
		++rectCount;
		shapesDrawn[shapesCount] = 'R';
		++shapesCount;

		// Draw a rectangle 
		rects[rectCount] = new Rectangle(new Point(0, 10), new Point(50, 75));
		rects[rectCount].Draw();
		++rectCount;
		shapesDrawn[shapesCount] = 'R';
		++shapesCount;

		// Draw a rectangle 
		rects[rectCount] = new Rectangle(new Point(15, 20), new Point(-100, -100));
		rects[rectCount].Draw();
		++rectCount;
		shapesDrawn[shapesCount] = 'R';
		++shapesCount;

		// Draw a Line
		lines[lineCount] = new Line(new Point(50, 50), new Point(90, 200));
		lines[lineCount].Draw();
		++lineCount;
		shapesDrawn[shapesCount] = 'L';
		++shapesCount;

		// Erase all objects in reverse order => Undo
		for (int i = shapesCount - 1; i >= 0; --i) {
			switch (shapesDrawn[i]) {
			case 'L':
				lines[lineCount - 1].Erase();
				--lineCount;
				break;

			case 'R':
				rects[rectCount - 1].Erase();
				--rectCount;
				break;
			}
		}
		shapesCount = 0;
	}

	public static void useShapeInheritance() {
		final int SIZE = 20;
		// Comment/Uncomment appropriate import statements at top of this source file.
		com.dac.java.shapeinheritance.Shape[] shapes = new com.dac.java.shapeinheritance.Shape[SIZE];
		int shapesCount = 0;

		// Draw a Line
		shapes[shapesCount] = new com.dac.java.shapeinheritance.Line(new Point(1, 1), new Point(10, 10)); 
		shapes[shapesCount].Draw();
		++shapesCount;

		// Draw a rectangle 
		shapes[shapesCount] = new com.dac.java.shapeinheritance.Rectangle(new Point(15, 20), new Point(-100, -100));
		shapes[shapesCount].Draw();
		++shapesCount;

		// Draw a rectangle 
		shapes[shapesCount] = new com.dac.java.shapeinheritance.Rectangle(new Point(0, 10), new Point(50, 75));
		shapes[shapesCount].Draw();
		++shapesCount;

		// Draw a rectangle 
		shapes[shapesCount] = new com.dac.java.shapeinheritance.Rectangle(new Point(15, 20), new Point(-100, -100));
		shapes[shapesCount].Draw();
		++shapesCount;

		// Draw a Line
		shapes[shapesCount] = new com.dac.java.shapeinheritance.Line(new Point(50, 50), new Point(90, 200));
		shapes[shapesCount].Draw();
		++shapesCount;

		// Erase all objects in reverse order => Undo
		for (int i = shapesCount - 1; i >= 0; --i) {
			shapes[i].getPoints();
			shapes[i].Erase();
		}
		shapesCount = 0;
	}

	public static void main(String[] args) {
		System.out.println("In main()");

		//useStudentInfoClass();

		//useLineAndRectangle();

		useShapeInheritance();
	}
}
