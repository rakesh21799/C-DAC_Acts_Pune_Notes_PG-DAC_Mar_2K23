package com.dac.java.shapeinheritance;

import com.dac.java.shape.Point;

public class Line extends Shape {
	public Line(Point s, Point e) {
		super(new Point[] {s, e});
		System.out.println("Line created.");
	}
/*
 	// Can not override final method.
	public Point[] getPoints() {
		System.out.println("Line getPoints");
		return null;
	}
*/
	public void Draw() {
		System.out.println("Draw Line (" + points[0].getX() + ", " + points[0].getY()
			+ ") (" + points[1].getX() + ", " + points[1].getY() + ")");
	}

	public void Erase() {
		System.out.println("Erase Line (" + points[0].getX() + ", " + points[0].getY()
			+ ") (" + points[1].getX() + ", " + points[1].getY() + ")");
	}
}
