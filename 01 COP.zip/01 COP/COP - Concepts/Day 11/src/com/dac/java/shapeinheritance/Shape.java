package com.dac.java.shapeinheritance;

import com.dac.java.shape.Point;

public abstract class Shape {
	protected Point[] points;

	public Shape(Point[] pts) {
		points = pts;
		System.out.println("Shape created.");
	}

	final public Point[] getPoints() {
		System.out.println("Shape getPoints");
		return points;
	}

	abstract public void Draw();

	abstract public void Erase();
}
