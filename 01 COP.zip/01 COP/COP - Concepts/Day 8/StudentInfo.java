public class StudentInfo {
	private int rollNo;
	private String name;

	public StudentInfo() {
		System.out.println("default constructor");
		rollNo = 1;
	}
	public StudentInfo(int rollNo, String name) {
		System.out.println("constructor with int, String");
		this.rollNo = rollNo;
		this.name = name;
	}
	public int GetRollNo() {
		return rollNo;
	}
}
