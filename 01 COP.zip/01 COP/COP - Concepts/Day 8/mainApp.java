
public class mainApp {

	public static void main(String[] args) {
		StudentInfo s1 = new StudentInfo();
		StudentInfo s2 = new StudentInfo(10, "Some Name");
		System.out.println("Roll no of s2 = " + s2.GetRollNo());
	}

}
