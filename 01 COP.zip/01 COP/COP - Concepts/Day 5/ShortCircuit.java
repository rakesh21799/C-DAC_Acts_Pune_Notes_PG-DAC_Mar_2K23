
public class ShortCircuit {
	public static boolean AcceptValidInput(boolean val) {
		System.out.println("AcceptValidInput");
		return val;
	}

	public static boolean ProcessInput(boolean val) {
		System.out.println("ProcessInput");
		return val;
	}

	public static void main(String[] args) {
		if (AcceptValidInput(false)) {
			if (ProcessInput(true)) {
				System.out.println("Success");
			} else {
				System.out.println("Failed");
			}
		} else {
			System.out.println("Failed");
		}

		if (AcceptValidInput(true) && ProcessInput(true)) {
			System.out.println("Success");
		} else {
			System.out.println("Failed");
		}
	}

}
