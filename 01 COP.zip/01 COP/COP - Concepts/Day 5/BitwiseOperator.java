
public class BitwiseOperator {

	public static void main(String[] args) {
		int num = 0;
		System.out.println("num = " + num);

		int mask = 0x1c;
		num = num | mask;
		System.out.println("num = " + num);

		int val = (num & mask) >> 2;
		System.out.println("val = " + val);

		// Clear all required bits => Store 0 in all the required bits.
		num = num & ~mask;
		System.out.println("num = " + num);

		// Set specific bits => Store 1 in specific bits.
		int maskFor101 = 0x14;
		num = num | maskFor101;
		System.out.println("num = " + num);

		//val = (num & mask); // 101 00
		val = (num & mask) >> 2; // 101
 		System.out.println("val = " + val);
	}
}
