
public class Day9 {
	public static int ReverseNum(int num) {
		int result = 0;
/*
		while (num >= 10) {
			result = result * 10 + (num % 10);
			num = num / 10;
		}

		result = result * 10 + num;
*/
		do {
			result = result * 10 + (num % 10);
			num = num / 10;
		} while (num != 0);

		return result;
	}

	public static void PrintNumInWords(int num) {
/*
		num = ReverseNum(num);
		while (num >= 10) {
			int digit = num % 10;
			num = num / 10;
			if (digit == 0) {
				System.out.print("zero ");
			} else if (digit == 1) {
				System.out.print("one ");
			} else if (digit == 2) {
				System.out.print("two ");
			} else {
				System.out.print("some ");
			}
		}
		if (num == 0) {
			System.out.print("zero ");
		} else if (num == 1) {
			System.out.print("one ");
		} else if (num == 2) {
			System.out.print("two ");
		} else {
			System.out.print("some ");
		}
		System.out.println("");
		*/
/*
		num = ReverseNum(num);
		do {
			int digit = num % 10;
			num = num / 10;
			if (digit == 0) {
				System.out.print("zero ");
			} else if (digit == 1) {
				System.out.print("one ");
			} else if (digit == 2) {
				System.out.print("two ");
			} else {
				System.out.print("some ");
			}
		} while (num != 0);
		System.out.println("");
*/
		int[] digits = new int[20];
		int digitCount = 0;
		do {
			int digit = num % 10;
			num = num / 10;
			digits[digitCount] = digit;
			++digitCount;
		} while (num != 0);
		for (int i = digitCount - 1; i >= 0; --i) {
			/*
			if (digits[i] == 0) {
				System.out.print("zero ");
			} else if (digits[i] == 1) {
				System.out.print("one ");
			} else if (digits[i] == 2) {
				System.out.print("two ");
			} else {
				System.out.print("some ");
			}
			*/
			switch (digits[i]) {
				case 0:
					System.out.print("zero ");
					break;
				case 1:
					System.out.print("one ");				
					break;
				case 2:
					System.out.print("two ");				
					break;
				case 3:
					System.out.print("three ");
					break;
				default:
					System.out.print("some ");
			}
		}
		System.out.println("");
	}

	public static void PrintNumInWordsFinal(int num) {
		String[] words = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
		int[] digits = new int[20];
		int digitCount = 0;
		do {
			int digit = num % 10;
			num = num / 10;
			digits[digitCount] = digit;
			++digitCount;
		} while (num != 0);
		for (int i = digitCount - 1; i >= 0; --i) {
			int digit = digits[i];
			System.out.print(words[digit] + " ");
		}
		System.out.println("");
	}

	public static void main(String[] args) {
		System.out.println("Reverse of 0 " + ReverseNum(0));
		System.out.println("Reverse of 9 " + ReverseNum(9));
		System.out.println("Reverse of 10 " + ReverseNum(10));
		System.out.println("Reverse of 15 " + ReverseNum(15));

		System.out.print("0 in words - ");
		PrintNumInWordsFinal(0);
		System.out.print("9 in words - ");
		PrintNumInWordsFinal(9);
		System.out.print("10 in words - ");
		PrintNumInWordsFinal(10);
		System.out.print("15 in words - ");
		PrintNumInWordsFinal(15);
	}

}
