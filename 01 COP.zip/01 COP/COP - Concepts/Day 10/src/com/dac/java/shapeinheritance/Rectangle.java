package com.dac.java.shapeinheritance;

import com.dac.java.shape.Point;

public class Rectangle extends Shape {
	public Rectangle(Point s, Point e) {
		super(new Point[] {s, e});
		System.out.println("Rectangle created.");
	}

	public void Draw() {
		System.out.println("Draw Rectangle (" + points[0].getX() + ", " + points[0].getY()
			+ ") (" + points[1].getX() + ", " + points[1].getY() + ")");
	}

	public void Erase() {
		System.out.println("Erase Rectangle (" + points[0].getX() + ", " + points[0].getY()
			+ ") (" + points[1].getX() + ", " + points[1].getY() + ")");
	}
}
