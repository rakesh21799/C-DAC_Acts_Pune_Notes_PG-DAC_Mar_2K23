package com.dac.java.student;

public class StudentInfo {
	private int rollNo;
	private String name;
	private static int currRollNo;

	static {
		currRollNo = 101;
	}

	public StudentInfo() {
		rollNo = currRollNo;
		++currRollNo;
	}

	public StudentInfo(String name) {
		rollNo = currRollNo;
		++currRollNo;
/*
		if ((name.charAt(0) >= 'a') && (name.charAt(0) >= 'z')) {
			char[] str = name.toCharArray();
			str[0] = (char) (str[0] - 'a' + 'A');
		}
*/
		if (Character.isLowerCase(name.charAt(0))) {
			char[] str = name.toCharArray();
			str[0] = Character.toUpperCase(str[0]);
			this.name = String.valueOf(str);
		} else {
			this.name = name;
		}
	}

	public int getRollNo() {
		return rollNo;
	}

	public String getName() {
		return name;
	}
}
