package com.dac.java.shape;

public class Rectangle {
	private Point bottomLeft;
	private Point topRight;
	public Rectangle(Point s, Point e) {
		bottomLeft = s;
		topRight = e;
	}
	public void Draw() {
		System.out.println("Draw Rectangle (" + bottomLeft.getX() + ", " + bottomLeft.getY()
			+ ") (" + topRight.getX() + ", " + topRight.getY() + ")");
	}
	public void Erase() {
		System.out.println("Erase Rectangle (" + bottomLeft.getX() + ", " + bottomLeft.getY()
			+ ") (" + topRight.getX() + ", " + topRight.getY() + ")");
	}
}
