package com.dac.java.shapeinheritance;

import com.dac.java.shape.Point;

public class Shape {
	protected Point[] points;

	public Shape(Point[] pts) {
		points = pts;
		System.out.println("Shape created.");
	}

	public Point[] getPoints() {
		return points;
	}

	public void Draw() {
		System.out.println("Draw shape");
	}

	public void Erase() {
		System.out.println("Erase shape");
	}
}
