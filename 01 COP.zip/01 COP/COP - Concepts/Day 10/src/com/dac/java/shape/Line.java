package com.dac.java.shape;

public class Line {
	private Point startPoint;
	private Point endPoint;
	public Line(Point s, Point e) {
		startPoint = s;
		endPoint = e;
	}
	public void Draw() {
		System.out.println("Draw Line (" + startPoint.getX() + ", " + startPoint.getY()
			+ ") (" + endPoint.getX() + ", " + endPoint.getY() + ")");
	}
	public void Erase() {
		System.out.println("Erase Line (" + startPoint.getX() + ", " + startPoint.getY()
			+ ") (" + endPoint.getX() + ", " + endPoint.getY() + ")");
	}
}
