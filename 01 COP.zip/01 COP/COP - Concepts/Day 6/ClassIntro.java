
public class ClassIntro {

	public static void main(String[] args) {
		StudentInfo s1 = new StudentInfo();
		s1.setRollNo(-10);
		System.out.println("Roll No = " + s1.getRollNo());
	}

}
