
public class StudentInfo {
	private int rollNo;
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		if (rollNo <= 0) {
			System.out.println("Invalid roll no.");
			return;
		}
		this.rollNo = rollNo;
	}
	public float getMarks1() {
		return marks1;
	}
	public void setMarks1(float marks1) {
		this.marks1 = marks1;
	}
	private float marks1;
}
